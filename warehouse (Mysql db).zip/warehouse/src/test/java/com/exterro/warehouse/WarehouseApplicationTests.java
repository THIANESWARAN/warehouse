package com.exterro.warehouse;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.exterro.warehouse.controller.ItemsController;
import com.exterro.warehouse.model.ItemsModel;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
//@AllArgsConstructor
@TestMethodOrder(OrderAnnotation.class)
@TestInstance(Lifecycle.PER_CLASS)
@Configuration
class WarehouseApplicationTests {

	private ItemsController itemsController;
	private ObjectMapper objectMapper = new ObjectMapper();
	private long itemId = 0;
	
	@Order(1)
	@BeforeAll
	void saveItems() throws Exception {
		itemsController = new ItemsController();
		List<ItemsModel> itemsList = new ArrayList<>();
		ItemsModel item = new ItemsModel();
		item.setName("testItem");
		item.setDescription("Junit Test");
		item.setPrice(530.40);
		itemsList.add(item);
		ResponseEntity<?> result = itemsController.saveItems(itemsList);
		Assertions.assertEquals(HttpStatus.CREATED,result.getStatusCode());
		/*
		String response = objectMapper.writeValueAsString(result.getBody());
		if(!response.equals("Success")) throw new Exception("un excepted output");
		*/
	}
	
	@Order(2)
	@Test
	void getItems() throws Exception {
		itemsController = new ItemsController();
		ResponseEntity<?> result = itemsController.getAllItems();
		Assertions.assertEquals(HttpStatus.OK,result.getStatusCode());
		List<ItemsModel> itemsList = (List<ItemsModel>) result.getBody();
		if(itemsList == null || itemsList.size() <= 0) throw new Exception("un excepted output");
		else itemId = itemsList.stream().filter(item->item.getName().equals("testItem")).findFirst().get().getId();
	}
	
	@Order(3)
	@AfterAll
	void deleteItem() throws Exception{
		itemsController = new ItemsController();
		System.out.println("itemid -> "+itemId);
		ResponseEntity<?> result = itemsController.deleteItem(itemId);
		Assertions.assertEquals(HttpStatus.OK,result.getStatusCode());
		/*
		String response = objectMapper.writeValueAsString(result.getBody());
		if(!response.equals("Success")) throw new Exception("un excepted output");
		*/
	}

}
