/**
 * 
 */
package com.exterro.warehouse.model;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * 
 */
@Data
@RequiredArgsConstructor
public class InventoryModel {
	private long id;
	private long itemId;
	private String itemName;
	private int quantity;
	private String location;
	private String createdTime;
	private int createdBy;
	private String updatedTime;
	private int updatedBy;
	
	public InventoryModel(OrderModel orderModel) {
		this.itemId = orderModel.getItemId();
		this.quantity = orderModel.getQuantity();
		this.createdTime = orderModel.getCreatedTime();
		this.createdBy = orderModel.getCreatedBy();
		this.updatedTime = orderModel.getUpdatedTime();
		this.createdBy = orderModel.getUpdatedBy();
	}
}
