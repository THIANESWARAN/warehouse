/**
 * 
 */
package com.exterro.warehouse.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.exterro.warehouse.model.InventoryModel;

/**
 * 
 */
@Component
public interface IInventoryService {

	List<InventoryModel> getInventoryDetails();
	
}
