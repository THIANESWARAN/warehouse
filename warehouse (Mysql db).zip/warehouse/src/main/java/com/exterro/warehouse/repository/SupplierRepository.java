/**
 * 
 */
package com.exterro.warehouse.repository;

import static com.exterro.warehouse.config.BaseClass.jdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.stereotype.Repository;
import com.exterro.warehouse.model.SupplierModel;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Repository
@Slf4j
public class SupplierRepository {
	public String saveSuppliers(List<SupplierModel> supplierList) {
		try {
			jdbcTemplate.batchUpdate("insert into supplier (name,contact_info,status,created_time,created_by) values (?,?,?,now(),1)", new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, supplierList.get(i).getName());
					ps.setString(2, supplierList.get(i).getContactInfo());
					ps.setString(3, supplierList.get(i).getStatus());
				}
				
				@Override
				public int getBatchSize() {
					return supplierList.size();
				}
			});
			return "Success";
		}catch (Exception e) {
			log.error("Error in saveSupplier -> "+e.getLocalizedMessage());
			return "Failure";
		}
	}
	
	public int updateSupplier(SupplierModel supplier) {
		int result = 0;
		try {
			result = jdbcTemplate.update("update supplier set name = ? , contact_info = ? , status = ? , updated_time = now(), updated_by = 1 where id = ? ;",supplier.getName(),supplier.getContactInfo(),supplier.getStatus(),supplier.getId());
		} catch (Exception e) {
			log.error("Error in updateSupplier -> "+e.getLocalizedMessage());
		}
		return result;
	}
	
	public int deleteSupplier(long itemId) {
		int result = 0;
		try {
			result = jdbcTemplate.update("delete from supplier where id = ? ;",itemId);
		} catch (Exception e) {
			log.error("Error in deleteSupplier -> "+e.getLocalizedMessage());
		}
		return result;
	}
	 
}
