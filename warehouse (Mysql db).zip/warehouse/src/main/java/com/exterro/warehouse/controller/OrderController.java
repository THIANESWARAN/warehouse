/**
 * 
 */
package com.exterro.warehouse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exterro.warehouse.config.BaseClass;
import com.exterro.warehouse.model.ErrorResponse;
import com.exterro.warehouse.model.OrderModel;
import com.exterro.warehouse.service.IOrderService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@RestController
@Slf4j
@AllArgsConstructor
public class OrderController extends BaseClass{

	@Autowired
	private IOrderService orderService;

	@PostMapping("/save/orders")
	public ResponseEntity<?> saveOrders(@RequestBody List<OrderModel> orderList){
		try {
			if(orderList != null && !orderList.isEmpty()) {
				return orderService.saveOrders(orderList);	
			}else {
				return new ResponseEntity<>(ORDER_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);	
			}
		}catch (Exception e) {
			log.error("Exception in getAllItems -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/update/order")
	public ResponseEntity<?> updateOrder(@RequestBody OrderModel orderData){
		try {
			if(orderData == null) {
				return new ResponseEntity<>(ORDER_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);	
			}
			return orderService.updateOrder(orderData);	
		}catch (Exception e) {
			log.error("Error in updateItem -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping("/delete/order/{orderId}")
	public ResponseEntity<?> deleteOrder(@PathVariable Long orderId){
		try {
			if(orderId <= 0) {
				return new ResponseEntity<>(ORDERID_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);
			}
			return orderService.deleteOrder(orderId);	
		} catch (Exception e) {
			log.error("Error in deleteOrder -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
}
