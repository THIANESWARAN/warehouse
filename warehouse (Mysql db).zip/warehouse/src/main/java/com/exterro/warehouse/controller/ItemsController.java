/**
 * 
 */
package com.exterro.warehouse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exterro.warehouse.config.BaseClass;
import com.exterro.warehouse.model.ErrorResponse;
import com.exterro.warehouse.model.ItemsModel;
import com.exterro.warehouse.service.IItemService;
import com.exterro.warehouse.service.impl.ItemServiceImpl;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@RestController
@Slf4j
@AllArgsConstructor
@RequiredArgsConstructor
public class ItemsController extends BaseClass{
	@Autowired
	private IItemService itemService = new ItemServiceImpl();
	
	@GetMapping("/get/items")
	public ResponseEntity<?> getAllItems(){
		try {
			List<ItemsModel> itemList = itemService.getAllItems();
			return new ResponseEntity<>(itemList,HttpStatus.OK);
		}catch (Exception e) {
			log.error("Exception in getAllItems -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/get/items/{itemId}")
	public ResponseEntity<?> getAllItems(@PathVariable Long itemId){
		try {
			if(itemId <= 0) {
				return new ResponseEntity<>(ITEMID_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);
			}
			ItemsModel item = itemService.getItemById(itemId);
			return new ResponseEntity<>(item,HttpStatus.OK);
		}catch (Exception e) {
			log.error("Exception in getAllItems -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/save/items")
	public ResponseEntity<?> saveItems(@RequestBody List<ItemsModel> itemList){
		try {
			if(itemList != null && !itemList.isEmpty()) {
				return itemService.saveItems(itemList);	
			}else {
				return new ResponseEntity<>(ITEM_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);	
			}
		}catch (Exception e) {
			log.error("Exception in getAllItems -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/update/item")
	public ResponseEntity<?> updateItem(@RequestBody ItemsModel item){
		try {
			if(item == null) {
				return new ResponseEntity<>(ITEM_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);	
			}
			return itemService.updateItem(item);	
		}catch (Exception e) {
			log.error("Error in updateItem -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping("/delete/item/{itemId}")
	public ResponseEntity<?> deleteItem(@PathVariable Long itemId){
		try {
			if(itemId <= 0) {
				return new ResponseEntity<>(ITEMID_VALIDATION_MESSAGE,HttpStatus.BAD_REQUEST);
			}
			return itemService.deleteItem(itemId);	
		} catch (Exception e) {
			log.error("Error in deleteItem -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}
	
	
}
