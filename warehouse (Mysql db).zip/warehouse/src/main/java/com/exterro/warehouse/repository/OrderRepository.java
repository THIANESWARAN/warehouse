/**
 * 
 */
package com.exterro.warehouse.repository;

import static com.exterro.warehouse.config.BaseClass.jdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.exterro.warehouse.model.ItemsModel;
import com.exterro.warehouse.model.OrderModel;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Repository
@AllArgsConstructor
@Slf4j
public class OrderRepository {
	
	public String saveOrders(List<OrderModel> orderList) {
		try {
			jdbcTemplate.batchUpdate("insert into `order` (item_id,supplier_id,quantity,order_date,created_time,created_by) values (?,?,?,?,now(),1)", new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setLong(1, orderList.get(i).getItemId());
					ps.setLong(2, orderList.get(i).getSupplierId());
					ps.setInt(3, orderList.get(i).getQuantity());
					ps.setString(4, orderList.get(i).getOrderDate());
				}
				
				@Override
				public int getBatchSize() {
					return orderList.size();
				}
			});
			return "Success";
		}catch (Exception e) {
			log.error("Error in saveOrders -> "+e.getLocalizedMessage());
			return "Failure";
		}
	}
	
	public int updateOrder(OrderModel orderData) {
		int result = 0;
		try {
			result = jdbcTemplate.update("update `order` set quantity = ? , order_date = ? , updated_time = now(), updated_by = 1 where id = ? ;",orderData.getQuantity(),orderData.getOrderDate(),orderData.getId());
		} catch (Exception e) {
			log.error("Error in updateOrder -> "+e.getLocalizedMessage());
		}
		return result;
	}
	
	public int deleteOrder(long orderId) {
		int result = 0;
		try {
			result = jdbcTemplate.update("delete from `order` where id = ? ;",orderId);
		} catch (Exception e) {
			log.error("Error in deleteOrder -> "+e.getLocalizedMessage());
		}
		return result;
	}
	
}
