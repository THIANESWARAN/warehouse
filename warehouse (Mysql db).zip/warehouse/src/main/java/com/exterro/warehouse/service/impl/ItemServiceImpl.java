/**
 * 
 */
package com.exterro.warehouse.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.exterro.warehouse.model.ItemsModel;
import com.exterro.warehouse.repository.ItemRepository;
import com.exterro.warehouse.service.IItemService;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Service
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class ItemServiceImpl implements IItemService{

	private ItemRepository itemRepository = new ItemRepository();
	
	@Override
	public List<ItemsModel> getAllItems() {
		List<ItemsModel> itemList = new ArrayList<>();
		try {
			itemList = itemRepository.getAllItem();
		}catch (Exception e) {
			log.error("Error in getAllItems -> "+e.getLocalizedMessage());
		}
		return itemList;
	}

	@Override
	public ItemsModel getItemById(long itemId) {
		ItemsModel item = new ItemsModel();
		try {
			item = itemRepository.getItemById(itemId);
		}catch (Exception e) {
			log.error("Error on getItemById "+e.getLocalizedMessage());
		}
		return item;
	}

	@Override
	public ResponseEntity<String> saveItems(List<ItemsModel> items) {
		String message = "";
		try {
			message = itemRepository.saveItems(items);
			
		}catch (Exception e) {
			log.error("Error in saveItems - >" +e.getLocalizedMessage());
			message = "failure";
		}
		if (message.equalsIgnoreCase("Success"))
			return new ResponseEntity<>(message, HttpStatus.CREATED);
		else
			return new ResponseEntity<>(message, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> updateItem(ItemsModel item) {
		int result = 0;
		try {
			result = itemRepository.updateItem(item);
		}catch (Exception e) {
			log.error("Exception in updateItem -> "+e.getLocalizedMessage());
		}
		if(result > 0)
			return new ResponseEntity<>("Sucess", HttpStatus.OK);
		else
			return new ResponseEntity<>("Failure", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> deleteItem(long itemId) {
		int result = 0;
		try {
			result = itemRepository.deleteItem(itemId);
		}catch (Exception e) {
			log.error("Exception in deleteItem -> "+e.getLocalizedMessage());
		}
		if(result > 0)
			return new ResponseEntity<>("Sucess", HttpStatus.OK);
		else
			return new ResponseEntity<>("Failure", HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
