/**
 * 
 */
package com.exterro.warehouse.repository;

import static com.exterro.warehouse.config.BaseClass.jdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

import com.exterro.warehouse.model.InventoryModel;
import com.exterro.warehouse.model.ItemsModel;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Repository
@Slf4j
public class InventoryRepository {

	public List<InventoryModel> getInventoryByItemId (String itemIds){
		List<InventoryModel> inventoryList = new ArrayList<>();
		try {
			inventoryList = jdbcTemplate.query(
					"select id, item_id itemId, quantity, location, created_time createdTime, created_by createdBy, updated_time updatedTime, updated_by updatedBy from inventory where item_id in ("+itemIds+");",
					new BeanPropertyRowMapper<InventoryModel>(InventoryModel.class));
		} catch (Exception e) {
			log.error("Error in getInventoryByItemId -> "+e.getLocalizedMessage());
		}
		return inventoryList;
	}
	
	public List<InventoryModel> getInventoryDetails(){
		List<InventoryModel> inventoryList = new ArrayList<>();
		try {
			inventoryList = jdbcTemplate.query(
					"select i.id, i.item_id itemId, it.name itemName, i.quantity, i.location, i.created_time createdTime, i.created_by createdBy, i.updated_time updatedTime, i.updated_by updatedBy from inventory i left join items it on it.id = i.item_id;",
					new BeanPropertyRowMapper<InventoryModel>(InventoryModel.class));
		} catch (Exception e) {
			log.error("Error in getInventoryByItemId -> "+e.getLocalizedMessage());
		}
		return inventoryList;
	}
	
	public String saveInventory(List<InventoryModel> inventoryList) {
		try {
			jdbcTemplate.batchUpdate("insert into inventory (item_id,quantity,location,created_time,created_by) values (?,?,?,now(),1)", new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setLong(1, inventoryList.get(i).getItemId());
					ps.setInt(2, inventoryList.get(i).getQuantity());
					ps.setString(3, inventoryList.get(i).getLocation());
				}
				
				@Override
				public int getBatchSize() {
					return inventoryList.size();
				}
			});
			return "Success";
		}catch (Exception e) {
			log.error("Error in saveInventory -> "+e.getLocalizedMessage());
			return "Failure";
		}
	}
	
	public int updateInventory(List<InventoryModel> inventoryList) {
		int result = 0;
		try {
			jdbcTemplate.batchUpdate("update inventory set quantity = ? , location = ? , updated_time = now(), updated_by = 1 where id = ? ;",new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setInt(1, inventoryList.get(i).getQuantity());
					ps.setString(2, inventoryList.get(i).getLocation());
					ps.setLong(3, inventoryList.get(i).getId());
				}
				
				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return inventoryList.size();
				}
			});
		} catch (Exception e) {
			log.error("Error in updateInventory -> "+e.getLocalizedMessage());
		}
		return result;
	}
	
}
