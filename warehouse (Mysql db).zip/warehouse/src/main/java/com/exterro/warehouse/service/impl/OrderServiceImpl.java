/**
 * 
 */
package com.exterro.warehouse.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.exterro.warehouse.model.InventoryModel;
import com.exterro.warehouse.model.ItemsModel;
import com.exterro.warehouse.model.OrderModel;
import com.exterro.warehouse.repository.InventoryRepository;
import com.exterro.warehouse.repository.OrderRepository;
import com.exterro.warehouse.service.IOrderService;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Service
@Slf4j
@AllArgsConstructor
@RequiredArgsConstructor
public class OrderServiceImpl implements IOrderService{
	
	private OrderRepository orderRepository;
	private InventoryRepository inventoryRepository;
	
	@Override
	public ResponseEntity<String> saveOrders(List<OrderModel> orderList) {
		String message = "";
		try {
			message = orderRepository.saveOrders(orderList);
			
		}catch (Exception e) {
			log.error("Error in saveItems - >" +e.getLocalizedMessage());
			message = "failure";
		}
		if (message.equalsIgnoreCase("Success")) {
			String itemIds = orderList.stream().map(order-> String.valueOf(order.getItemId())).distinct().collect(Collectors.joining(","));
			log.warn("item Ids -> "+itemIds);
			List<InventoryModel> inventoryList = inventoryRepository.getInventoryByItemId(itemIds);
			
			if(inventoryList != null && !inventoryList.isEmpty()) {
				inventoryList.forEach(inventory -> {
					OrderModel currentOrder = orderList.stream().filter(order->order.getItemId() == inventory.getItemId()).findFirst().orElse(null);
					if(currentOrder != null) {
						int currentQty = currentOrder.getQuantity();
						int newQty = inventory.getQuantity() + currentQty;
						inventory.setQuantity(newQty);
					}
				});
				inventoryRepository.updateInventory(inventoryList);
			}else {
				inventoryList = new ArrayList<>();
				for (OrderModel order : orderList) {
					inventoryList.add(new InventoryModel(order));
				}
				inventoryRepository.saveInventory(inventoryList);
			}
			return new ResponseEntity<>(message, HttpStatus.CREATED);	
		}
		else
			return new ResponseEntity<>(message, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> updateOrder(OrderModel order) {
		int result = 0;
		try {
			result = orderRepository.updateOrder(order);
		}catch (Exception e) {
			log.error("Exception in updateOrder -> "+e.getLocalizedMessage());
		}
		if(result > 0)
			return new ResponseEntity<>("Sucess", HttpStatus.OK);
		else
			return new ResponseEntity<>("Failure", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> deleteOrder(long orderId) {
		int result = 0;
		try {
			result = orderRepository.deleteOrder(orderId);
		}catch (Exception e) {
			log.error("Exception in deleteItem -> "+e.getLocalizedMessage());
		}
		if(result > 0)
			return new ResponseEntity<>("Sucess", HttpStatus.OK);
		else
			return new ResponseEntity<>("Failure", HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
