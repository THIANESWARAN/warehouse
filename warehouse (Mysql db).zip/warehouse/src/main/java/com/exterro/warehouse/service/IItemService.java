/**
 * 
 */
package com.exterro.warehouse.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.exterro.warehouse.model.ItemsModel;

/**
 * 
 */
@Component
public interface IItemService {
	
	/**
	 * 
	 */
	List<ItemsModel> getAllItems();
	
	
	ItemsModel getItemById(long itemId);
	
	ResponseEntity<String> saveItems(List<ItemsModel> items);
	
	ResponseEntity<String> updateItem(ItemsModel item);
	
	ResponseEntity<String> deleteItem(long itemId);

}
