/**
 * 
 */
package com.exterro.warehouse.model;

import lombok.Data;

/**
 * 
 */
@Data
public class SupplierModel {
	private long id;
	private String name;
	private String contactInfo;
	private String status;
	private String createdTime;
	private int createdBy;
	private String updatedTime;
	private int updatedBy;
}
