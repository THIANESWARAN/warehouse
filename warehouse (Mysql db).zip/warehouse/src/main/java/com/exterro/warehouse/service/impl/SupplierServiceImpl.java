/**
 * 
 */
package com.exterro.warehouse.service.impl;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.exterro.warehouse.model.SupplierModel;
import com.exterro.warehouse.repository.SupplierRepository;
import com.exterro.warehouse.service.ISupplierService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Service
@Slf4j
@AllArgsConstructor
public class SupplierServiceImpl implements ISupplierService{

	private SupplierRepository supplierRepository;
	
	@Override
	public ResponseEntity<String> saveSuppliers(List<SupplierModel> supplierList) {
		String message = "";
		try {
			message = supplierRepository.saveSuppliers(supplierList);
			
		}catch (Exception e) {
			log.error("Error in saveSaveSuppliers - >" +e.getLocalizedMessage());
			message = "failure";
		}
		if (message.equalsIgnoreCase("Success"))
			return new ResponseEntity<>(message, HttpStatus.CREATED);
		else
			return new ResponseEntity<>(message, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> updateSupplier(SupplierModel supplier) {
		int result = 0;
		try {
			result = supplierRepository.updateSupplier(supplier);
		}catch (Exception e) {
			log.error("Exception in updateSupplier -> "+e.getLocalizedMessage());
		}
		if(result > 0)
			return new ResponseEntity<>("Sucess", HttpStatus.OK);
		else
			return new ResponseEntity<>("Failure", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@Override
	public ResponseEntity<String> deleteSupplier(long supplierId) {
		int result = 0;
		try {
			result = supplierRepository.deleteSupplier(supplierId);
		}catch (Exception e) {
			log.error("Exception in delete Supplier -> "+e.getLocalizedMessage());
		}
		if(result > 0)
			return new ResponseEntity<>("Sucess", HttpStatus.OK);
		else
			return new ResponseEntity<>("Failure", HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
