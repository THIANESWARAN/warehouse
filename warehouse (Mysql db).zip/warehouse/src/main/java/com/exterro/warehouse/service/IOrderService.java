/**
 * 
 */
package com.exterro.warehouse.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.exterro.warehouse.model.OrderModel;

/**
 * 
 */
@Component
public interface IOrderService {
	ResponseEntity<String> saveOrders(List<OrderModel> orderList);
	
	ResponseEntity<String> updateOrder(OrderModel orderData);
	
	ResponseEntity<String> deleteOrder(long orderId);
}
