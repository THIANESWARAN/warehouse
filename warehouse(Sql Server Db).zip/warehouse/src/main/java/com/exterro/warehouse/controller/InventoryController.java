/**
 * 
 */
package com.exterro.warehouse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exterro.warehouse.model.ErrorResponse;
import com.exterro.warehouse.model.InventoryModel;
import com.exterro.warehouse.model.ItemsModel;
import com.exterro.warehouse.service.IInventoryService;
import com.exterro.warehouse.service.IItemService;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@RestController
@Slf4j
@AllArgsConstructor
@RequiredArgsConstructor
public class InventoryController {
	@Autowired
	private IInventoryService inventoryService;
	
	@GetMapping("/get/inventory")
	public ResponseEntity<?> getAllItems(){
		try {
			List<InventoryModel> inventoryList = inventoryService.getInventoryDetails();
			return new ResponseEntity<>(inventoryList,HttpStatus.OK);
		}catch (Exception e) {
			log.error("Exception in inventoryItems -> "+e.getLocalizedMessage());
			ErrorResponse errorResponse = new ErrorResponse(HttpStatus.BAD_REQUEST, e.getLocalizedMessage());
			return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
		}
	}

}
