/**
 * 
 */
package com.exterro.warehouse.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.exterro.warehouse.model.SupplierModel;

/**
 * 
 */
@Component
public interface ISupplierService {
	
	ResponseEntity<String> saveSuppliers(List<SupplierModel> items);
	
	ResponseEntity<String> updateSupplier(SupplierModel item);
	
	ResponseEntity<String> deleteSupplier(long itemId);
}
