package com.exterro.warehouse.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

//import com.mysql.cj.jdbc.MysqlDataSource;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public class BaseClass {

	@Value("${spring.datasource.url}")
	public String url;
	@Value("${spring.datasource.username}")
	public String userName;
	@Value("${spring.datasource.password}")
	public String password;
	
	public static final String ITEMID_VALIDATION_MESSAGE = "Item Id Cannot be Less than or Equal to Zero";
	
	public static final String ITEM_VALIDATION_MESSAGE = "Item (or) Item list cannot be empty";
	
	public static final String SUPLLIER_VALIDATION_MESSAGE = "Supplier (or) Supplier list cannot be empty";
	
	public static final String SUPLLIERID_VALIDATION_MESSAGE = "Supplier Id Cannot be Less than or Equal to Zero";
	
	public static final String ORDER_VALIDATION_MESSAGE = "Order (or) Order list cannot be empty";
	
	public static final String ORDERID_VALIDATION_MESSAGE = "Order Id Cannot be Less than or Equal to Zero";
	
	public static JdbcTemplate jdbcTemplate;

	/*
	@Bean
	JdbcTemplate jdbcIntialize() {
		System.out.println("URL -> " + url);
		MysqlDataSource dataSource = new MysqlDataSource();
		dataSource.setURL(url);
		dataSource.setUser(userName);
		dataSource.setPassword(password);
		jdbcTemplate = new JdbcTemplate(dataSource);
		return jdbcTemplate;
	}
	*/
	
	@Bean
	JdbcTemplate jdbcIntialize()  {
		System.out.println("URL -> " + url);
		SQLServerDataSource dataSource = new SQLServerDataSource();
		dataSource.setURL(url);
		dataSource.setUser(userName);
		dataSource.setPassword(password);
		jdbcTemplate = new JdbcTemplate(dataSource);
		return jdbcTemplate;
	}

}
