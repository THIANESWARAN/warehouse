/**
 * 
 */
package com.exterro.warehouse.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.exterro.warehouse.model.ItemsModel;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import static com.exterro.warehouse.config.BaseClass.jdbcTemplate;

/**
 * 
 */
@Repository
@AllArgsConstructor
@Slf4j
public class ItemRepository {
	
	public List<ItemsModel> getAllItem(){
		List<ItemsModel> itemsModels = new ArrayList<>();
		try {
			itemsModels = jdbcTemplate.query(
					"select id, name, description, price, created_time createdTime, created_by createdBy, updated_time updatedTime, updated_by updatedBy from items;",
					new BeanPropertyRowMapper<ItemsModel>(ItemsModel.class));
		} catch (Exception e) {
			log.error("Error in getAllItem -> "+e.getLocalizedMessage());
		}
		return itemsModels;
	}
	
	public ItemsModel getItemById(long itemId){
		ItemsModel itemsModel = new ItemsModel();
		try {
			itemsModel = jdbcTemplate.queryForObject(
					"select id, name, description, price, created_time createdTime, created_by createdBy, updated_time updatedTime, updated_by updatedBy from items where id = ? ;",
					new BeanPropertyRowMapper<ItemsModel>(ItemsModel.class),itemId);
		} catch (Exception e) {
			log.error("Error in getAllItem -> "+e.getLocalizedMessage());
		}
		return itemsModel;
	}
	
	public String saveItems(List<ItemsModel> itemList) {
		try {
			// String query = "insert into items (name,description,price,created_time,created_by) values (?,?,?,now(),1)";
			String query = "insert into items (name,description,price,created_time,created_by) values (?,?,?,GETDATE(),1)";
			jdbcTemplate.batchUpdate(query, new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, itemList.get(i).getName());
					ps.setString(2, itemList.get(i).getDescription());
					ps.setDouble(3, itemList.get(i).getPrice());
				}
				
				@Override
				public int getBatchSize() {
					return itemList.size();
				}
			});
			return "Success";
		}catch (Exception e) {
			log.error("Error in saveItems -> "+e.getLocalizedMessage());
			return "Failure";
		}
	}
	
	public int updateItem(ItemsModel itemsModel) {
		int result = 0;
		// String query = "update items set name = ? , description = ? , price = ? , updated_time = now(), updated_by = 1 where id = ? ;";
		String query = "update items set name = ? , description = ? , price = ? , updated_time = GETDATE(), updated_by = 1 where id = ? ;";
		try {
			result = jdbcTemplate.update(query,itemsModel.getName(),itemsModel.getDescription(),itemsModel.getPrice(),itemsModel.getId());
		} catch (Exception e) {
			log.error("Error in updateItem -> "+e.getLocalizedMessage());
		}
		return result;
	}
	
	public int deleteItem(long itemId) {
		int result = 0;
		try {
			result = jdbcTemplate.update("delete from items where id = ? ;",itemId);
		} catch (Exception e) {
			log.error("Error in deleteItem -> "+e.getLocalizedMessage());
		}
		return result;
	}
	
}
