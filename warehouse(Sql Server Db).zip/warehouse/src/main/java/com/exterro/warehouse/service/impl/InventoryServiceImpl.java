/**
 * 
 */
package com.exterro.warehouse.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.exterro.warehouse.model.InventoryModel;
import com.exterro.warehouse.model.ItemsModel;
import com.exterro.warehouse.repository.InventoryRepository;
import com.exterro.warehouse.service.IInventoryService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Service
@Slf4j
@AllArgsConstructor
public class InventoryServiceImpl implements IInventoryService{

	private InventoryRepository inventoryRepository;
	
	@Override
	public List<InventoryModel> getInventoryDetails() {
		List<InventoryModel> itemList = new ArrayList<>();
		try {
			itemList = inventoryRepository.getInventoryDetails();
		}catch (Exception e) {
			log.error("Error in getInventoryDetails -> "+e.getLocalizedMessage());
		}
		return itemList;
	}
	
	

}
