/**
 * 
 */
package com.exterro.warehouse.model;

import lombok.Data;

/**
 * 
 */
@Data
public class OrderModel {
	private long id;
	private long itemId;
	private long supplierId;
	private int quantity;
	private String orderDate;
	private String status;
	private String createdTime;
	private int createdBy;
	private String updatedTime;
	private int updatedBy;
	
}
