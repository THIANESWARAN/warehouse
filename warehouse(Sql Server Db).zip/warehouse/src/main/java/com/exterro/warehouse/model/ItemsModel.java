/**
 * 
 */
package com.exterro.warehouse.model;

import lombok.Data;

/**
 * 
 */
@Data
public class ItemsModel {
	private int id;
	private String name;
	private String description;
	private double price; 
	private String createdTime;
	private int createdBy;
	private String updatedTime;
	private int updatedBy;
}
